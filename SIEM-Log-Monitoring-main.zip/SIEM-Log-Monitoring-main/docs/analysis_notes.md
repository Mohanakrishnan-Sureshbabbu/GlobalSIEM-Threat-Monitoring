# Analysis Notes

- Failed logins threshold = 3
- Correlation rule triggered for suspicious IPs
- Alerts stored in `alerts.json`

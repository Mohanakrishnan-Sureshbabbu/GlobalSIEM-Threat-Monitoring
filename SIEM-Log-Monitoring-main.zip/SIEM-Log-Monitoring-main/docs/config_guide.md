# Config Guide

- **log_sources** → Path to log files
- **alert_thresholds** → Rule parameters
- **output** → Where alerts are stored

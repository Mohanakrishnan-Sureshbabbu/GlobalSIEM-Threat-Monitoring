# Sample SIEM Report

**Date:** 2025-08-15  
**System:** SIEM Log Monitoring  

### Alerts Generated
- Multiple failed logins detected.  
- Suspicious IP activity from `203.0.113.45`.  

### Recommendation
- Block IP in firewall  
- Investigate login attempts  
- Strengthen authentication
